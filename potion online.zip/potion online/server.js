require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const path = require('path');
const User = require('./models/User');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

// Middleware
app.use(express.json());

// Nastavení statických souborů
app.use(express.static(path.join(__dirname, 'public')));
app.use('/css', express.static(path.join(__dirname, 'public/css')));
app.use('/js', express.static(path.join(__dirname, 'public/js')));

// Přesměrování kořenové cesty na index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Middleware pro ověření JWT tokenu
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.status(401).json({ message: 'Není přihlášen' });

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ message: 'Neplatný token' });
        req.user = user;
        next();
    });
};

// MongoDB připojení
mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('✅ Úspěšně připojeno k MongoDB'))
    .catch(err => console.error('❌ Chyba připojení k MongoDB:', err));

// Registrace
app.post('/api/register', async (req, res) => {
    try {
        const { username, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ username, password: hashedPassword });
        await user.save();
        res.status(201).json({ message: 'Registrace úspěšná' });
    } catch (error) {
        res.status(400).json({ message: 'Uživatelské jméno již existuje' });
    }
});

// Přihlášení
app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findOne({ username });
        
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: 'Nesprávné přihlašovací údaje' });
        }

        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
        res.json({ token, username: user.username });
    } catch (error) {
        res.status(500).json({ message: 'Chyba serveru' });
    }
});

// Načtení dat hráče
app.get('/api/user/data', authenticateToken, async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        if (!user) {
            return res.status(404).json({ message: 'Uživatel nenalezen' });
        }
        res.json(user);
    } catch (error) {
        console.error('Chyba při načítání dat:', error);
        res.status(500).json({ message: 'Chyba při načítání dat' });
    }
});

// Aktualizace statistik
app.post('/api/user/update-stats', authenticateToken, async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        if (!user) {
            return res.status(404).json({ message: 'Uživatel nenalezen' });
        }

        // Validace dat před uložením
        const { gameStats, buffs, inventory } = req.body;
        
        if (gameStats) {
            user.gameStats = {
                level: Number(gameStats.level) || user.gameStats.level,
                experience: Number(gameStats.experience) || user.gameStats.experience,
                gold: Number(gameStats.gold) || user.gameStats.gold,
                clickPower: Number(gameStats.clickPower) || user.gameStats.clickPower,
                bossesDefeated: Number(gameStats.bossesDefeated) || user.gameStats.bossesDefeated
            };
        }

        if (buffs) {
            user.buffs = {
                strength: Number(buffs.strength) || user.buffs.strength,
                health: Number(buffs.health) || user.buffs.health,
                luck: Number(buffs.luck) || user.buffs.luck
            };
        }

        if (inventory) {
            user.inventory = {
                ingredients: Array.isArray(inventory.ingredients) ? inventory.ingredients : [],
                potions: Array.isArray(inventory.potions) ? inventory.potions : []
            };
        }

        await user.save();
        res.json({ message: 'Data úspěšně uložena', user });
    } catch (error) {
        console.error('Chyba při ukládání dat:', error);
        res.status(500).json({ message: 'Chyba při ukládání dat' });
    }
});

// Socket.io připojení
io.on('connection', (socket) => {
    console.log('👤 Nový uživatel se připojil');
    
    socket.on('disconnect', () => {
        console.log('👋 Uživatel se odpojil');
    });
});

// Spuštění serveru
const PORT = process.env.PORT || 3000;
http.listen(PORT, () => {
    console.log(`🚀 Server běží na portu ${PORT}`);
});

// Ošetření neočekávaných chyb
process.on('unhandledRejection', (error) => {
    console.error('❌ Neošetřená Promise rejection:', error);
});

process.on('uncaughtException', (error) => {
    console.error('❌ Neošetřená chyba:', error);
    process.exit(1);
});