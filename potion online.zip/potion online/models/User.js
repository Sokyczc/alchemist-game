const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    gameStats: {
        level: { type: Number, default: 1 },
        experience: { type: Number, default: 0 },
        gold: { type: Number, default: 0 },
        clickPower: { type: Number, default: 1 },
        bossesDefeated: { type: Number, default: 0 }
    },
    buffs: {
        strength: { type: Number, default: 0 },
        health: { type: Number, default: 100 },
        luck: { type: Number, default: 0 }
    },
    inventory: {
        ingredients: [{
            id: String,
            name: String,
            rarity: String,
            effect: String,
            value: Number
        }],
        potions: [{
            id: String,
            name: String,
            effect: String,
            power: Number,
            value: Number
        }]
    }
});

module.exports = mongoose.model('User', userSchema); 