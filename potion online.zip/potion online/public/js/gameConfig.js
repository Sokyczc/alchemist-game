const GAME_CONFIG = {
    // Boss konfigurace
    BOSS: {
        BASE_HEALTH: 100,
        NAMES: {
            COMMON: ['Goblin', 'Skřet', 'Vlk', 'Bandita', 'Zombie'],
            UNCOMMON: ['Ogr', 'Troll', 'Minotaur', 'Harpyje', 'Ghoul'],
            RARE: ['Démon', 'Drak', 'Hydra', 'Mantikora', 'Bazilišek'],
            EPIC: ['Arcidémon', 'Kostěj', 'Fénix', 'Behemot', 'Leviatan'],
            LEGENDARY: ['Prastarý drak', 'Bůh smrti', 'Titán', 'Arcimág', 'Světlonošec']
        },
        HP_MULTIPLIER: 50, // HP za každý level hráče
        RARITY_MULTIPLIERS: {
            COMMON: 1,
            UNCOMMON: 1.5,
            RARE: 2,
            EPIC: 3,
            LEGENDARY: 5
        },
        RARITY_CHANCES: {
            COMMON: 50,
            UNCOMMON: 25,
            RARE: 15,
            EPIC: 8,
            LEGENDARY: 2
        }
    },
    
    // Ingredience
    INGREDIENTS: {
        TYPES: [
            { name: 'Dračí šupina', baseValue: 10 },
            { name: 'Kouzelný prach', baseValue: 8 },
            { name: 'Lesní houba', baseValue: 5 },
            { name: 'Měsíční květ', baseValue: 15 },
            { name: 'Ohnivý kořen', baseValue: 12 }
        ],
        RARITY_MULTIPLIERS: {
            COMMON: 1,
            UNCOMMON: 2,
            RARE: 4,
            EPIC: 8,
            LEGENDARY: 16
        }
    },
    
    // Potion konfigurace
    POTIONS: {
        TYPES: {
            STRENGTH: 'Lektvar síly',
            HEALTH: 'Lektvar zdraví',
            LUCK: 'Lektvar štěstí',
            EXPERIENCE: 'Lektvar zkušeností'
        },
        MIN_INGREDIENTS: 2,
        MAX_INGREDIENTS: 4
    }
}; 