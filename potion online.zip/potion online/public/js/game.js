const socket = io();

class Game {
    constructor() {
        this.player = {
            gameStats: {
                level: 1,
                experience: 0,
                gold: 0,
                clickPower: 1,
                bossesDefeated: 0
            },
            buffs: {
                strength: 0,
                health: 100,
                luck: 0
            }
        };
        this.currentBoss = this.generateNewBoss();
        this.gameArea = document.getElementById('game-area');
        this.setupGameArea();
        this.currentIngredients = [];
        this.currentIngredientsInCauldron = [];
        this.potions = [];
        this.setupDragAndDrop();
        this.setupBossClickHandler();
        this.setupPotionUsage();

        console.log('Game initialized:', {
            player: this.player,
            currentBoss: this.currentBoss,
            ingredients: this.currentIngredients
        });

        // Načtení uloženého stavu
        this.loadGameState();

        // Nastavení automatického ukládání každých 30 sekund
        setInterval(() => this.saveGameState(), 30000);
    }

    setupGameArea() {
        this.gameArea.innerHTML = `
            <div class="left-panel">
                <div id="player-stats" class="panel">
                    <h3>Statistiky hráče</h3>
                    <div class="stat-item">
                        <span class="stat-icon">📊</span>
                        <span>Úroveň: <span id="player-level">1</span></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-icon">📚</span>
                        <span>Zkušenosti: <span id="player-experience">0</span></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-icon">💰</span>
                        <span>Zlato: <span id="player-gold">0</span></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-icon">⚔️</span>
                        <span>Síla kliknutí: <span id="player-click-power">1</span></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-icon">👊</span>
                        <span>Poražení bossové: <span id="player-bosses-defeated">0</span></span>
                    </div>
                    <h4>Aktivní buffy</h4>
                    <div class="stat-item">
                        <span class="stat-icon">🗡️</span>
                        <span>Síla: <span id="player-strength">0</span></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-icon">❤️</span>
                        <span>Zdraví: <span id="player-health">100</span></span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-icon">🍀</span>
                        <span>Štěstí: <span id="player-luck">0</span></span>
                    </div>
                </div>
                <div id="inventory" class="panel">
                    <h3>Inventář</h3>
                    <div class="inventory-grid">
                        <div class="inventory-section">
                            <h4>Ingredience</h4>
                            <div class="dropzone" id="ingredients-inventory"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="center-panel">
                <div id="boss-container">
                    <div id="boss-info">
                        <h3 id="boss-name"></h3>
                        <p>Level: <span id="boss-level"></span></p>
                        <p>Rarita: <span id="boss-rarity"></span></p>
                        <p>Zdraví: <span id="boss-health"></span></p>
                    </div>
                    <div id="boss-health-bar">
                        <div class="health-bar-fill"></div>
                    </div>
                    <div id="boss-sprite"></div>
                </div>
            </div>

            <div class="right-panel">
                <div id="alchemy" class="panel">
                    <h3>Alchymie</h3>
                    <div id="cauldron">
                        <div id="cauldron-content"></div>
                    </div>
                    <div id="potions-inventory" class="inventory-grid"></div>
                </div>
            </div>
        `;
    }

    async loadPlayerData() {
        try {
            const response = await fetch('/api/user/data', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            const data = await response.json();
            console.log('Loaded player data:', data);
            
            if (data && data.gameStats) {
                this.player = data;
                this.updateUI();
            } else {
                console.warn('Invalid player data received:', data);
            }
        } catch (error) {
            console.error('Error loading player data:', error);
            console.error('Stack trace:', error.stack);
        }
    }

    updateUI() {
        // Aktualizace základních statistik
        document.getElementById('player-level').textContent = this.player.gameStats.level;
        document.getElementById('player-experience').textContent = this.player.gameStats.experience;
        document.getElementById('player-gold').textContent = this.player.gameStats.gold;
        document.getElementById('player-click-power').textContent = this.player.gameStats.clickPower;
        document.getElementById('player-bosses-defeated').textContent = this.player.gameStats.bossesDefeated;
        
        // Aktualizace buffů
        document.getElementById('player-strength').textContent = this.player.gameStats.clickPower;  // Změněno z buffs.strength
        document.getElementById('player-health').textContent = this.player.buffs.health;
        document.getElementById('player-luck').textContent = this.player.buffs.luck;

        // Uložení stavu hry
        this.saveGameState();
    }

    generateRandomIngredient(bossRarity) {
        const types = GAME_CONFIG.INGREDIENTS.TYPES;
        const randomType = types[Math.floor(Math.random() * types.length)];
        
        return {
            name: randomType.name,
            rarity: bossRarity,
            effect: this.generateRandomEffect(),
            value: randomType.baseValue * GAME_CONFIG.INGREDIENTS.RARITY_MULTIPLIERS[bossRarity]
        };
    }

    generateRandomEffect() {
        const effects = Object.keys(GAME_CONFIG.POTIONS.TYPES);
        return effects[Math.floor(Math.random() * effects.length)];
    }

    setupDragAndDrop() {
        const ingredientsInventory = document.getElementById('ingredients-inventory');
        const cauldron = document.getElementById('cauldron');
        
        // Nastavení Drag & Drop pro ingredience
        ingredientsInventory.addEventListener('dragstart', (e) => {
            if (e.target.classList.contains('ingredient')) {
                e.dataTransfer.setData('text/plain', e.target.id);
            }
        });

        cauldron.addEventListener('dragover', (e) => {
            e.preventDefault();
            cauldron.classList.add('dragover');
        });

        cauldron.addEventListener('dragleave', () => {
            cauldron.classList.remove('dragover');
        });

        cauldron.addEventListener('drop', (e) => {
            e.preventDefault();
            cauldron.classList.remove('dragover');
            const ingredientId = e.dataTransfer.getData('text/plain');
            this.addIngredientToCauldron(ingredientId);
        });
    }

    addIngredientToCauldron(ingredientId) {
        const ingredient = this.currentIngredients.find(i => i.id === ingredientId);
        if (!ingredient) return;

        // Přidání do kotle
        const cauldronContent = document.getElementById('cauldron-content');
        const element = document.getElementById(ingredientId);
        
        if (element && cauldronContent) {
            // Přidání vizuálního efektu
            const newHeight = Math.min(100, (this.currentIngredientsInCauldron.length + 1) * 25);
            cauldronContent.style.height = `${newHeight}%`;
            
            // Přidání do seznamu ingrediencí v kotli
            this.currentIngredientsInCauldron.push(ingredient);
            
            // Odstranění z inventáře
            element.remove();
            
            // Kontrola počtu ingrediencí pro vaření
            if (this.currentIngredientsInCauldron.length >= GAME_CONFIG.POTIONS.MIN_INGREDIENTS) {
                this.brewPotion();
            }
        }
    }

    brewPotion() {
        console.log('Vaření lektvaru začíná...');
        if (!this.currentIngredientsInCauldron || this.currentIngredientsInCauldron.length < GAME_CONFIG.POTIONS.MIN_INGREDIENTS) {
            console.log('Nedostatek ingrediencí pro vaření');
            return;
        }

        // Získání efektů z ingrediencí
        const effects = this.currentIngredientsInCauldron.map(i => i.effect);
        console.log('Efekty ingrediencí:', effects);
        
        const mainEffect = this.getMostCommonEffect(effects);
        console.log('Hlavní efekt:', mainEffect);

        // Vytvoření lektvaru se správným efektem
        const potion = {
            id: `potion-${Date.now()}`,
            name: GAME_CONFIG.POTIONS.TYPES[mainEffect],
            effect: mainEffect,
            power: this.calculatePotionPower(),
            value: this.calculatePotionValue()
        };

        console.log('Vytvořený lektvar:', potion);
        this.addPotionToInventory(potion);
        this.clearCauldron();
    }

    getMostCommonEffect(effects) {
        return effects.sort((a,b) =>
            effects.filter(v => v === a).length - effects.filter(v => v === b).length
        ).pop();
    }

    calculatePotionValue() {
        return this.currentIngredientsInCauldron.reduce((acc, ing) => acc + ing.value, 0);
    }

    calculatePotionPower() {
        const baseValue = 10;
        const rarityMultiplier = this.currentIngredientsInCauldron.reduce((acc, ing) => 
            acc + GAME_CONFIG.INGREDIENTS.RARITY_MULTIPLIERS[ing.rarity], 0);
        return Math.floor(baseValue * (rarityMultiplier / this.currentIngredientsInCauldron.length));
    }

    clearCauldron() {
        this.currentIngredientsInCauldron = [];
        const cauldronContent = document.getElementById('cauldron-content');
        cauldronContent.style.height = '0%';
    }

    generateNewBoss() {
        const rarity = this.generateBossRarity();
        const possibleNames = GAME_CONFIG.BOSS.NAMES[rarity];
        const name = possibleNames[Math.floor(Math.random() * possibleNames.length)];
        
        // Výpočet HP podle levelu hráče a rarity
        const baseHealth = GAME_CONFIG.BOSS.BASE_HEALTH + 
            (this.player.gameStats.level * GAME_CONFIG.BOSS.HP_MULTIPLIER);
        const healthMultiplier = GAME_CONFIG.BOSS.RARITY_MULTIPLIERS[rarity];
        const maxHealth = Math.floor(baseHealth * healthMultiplier);

        return {
            name: name,
            level: this.player.gameStats.level,
            rarity: rarity,
            maxHealth: maxHealth,
            health: maxHealth
        };
    }

    generateBossRarity() {
        const rand = Math.random() * 100;
        let cumulative = 0;
        
        for (const [rarity, chance] of Object.entries(GAME_CONFIG.BOSS.RARITY_CHANCES)) {
            cumulative += chance;
            if (rand <= cumulative) return rarity;
        }
        return 'COMMON';
    }

    setupBossClickHandler() {
        const bossSprite = document.getElementById('boss-sprite');
        bossSprite.addEventListener('click', () => this.attackBoss());
    }

    attackBoss() {
        if (!this.currentBoss) return;

        // Výpočet poškození
        let damage = this.player.gameStats.clickPower;
        if (this.player.buffs.strength > 0) {
            damage *= (1 + this.player.buffs.strength / 100);
        }

        // Aplikace poškození
        this.currentBoss.health -= damage;
        this.updateBossHealthBar();

        // Kontrola porážky bosse
        if (this.currentBoss.health <= 0) {
            this.defeatBoss();
        }
    }

    updateBossHealthBar() {
        const healthBar = document.querySelector('.health-bar-fill');
        const healthPercent = (this.currentBoss.health / this.currentBoss.maxHealth) * 100;
        healthBar.style.width = `${Math.max(0, healthPercent)}%`;
    }

    defeatBoss() {
        // Přidání odměn
        const baseReward = 10 * this.currentBoss.level;
        const expMultiplier = GAME_CONFIG.BOSS.RARITY_MULTIPLIERS[this.currentBoss.rarity];
        const goldMultiplier = this.player.buffs.luck > 0 ? 
            (1 + this.player.buffs.luck / 100) : 1;

        // Aktualizace statistik hráče
        this.player.gameStats.experience += Math.floor(baseReward * expMultiplier);
        this.player.gameStats.gold += Math.floor(baseReward * goldMultiplier);
        this.player.gameStats.bossesDefeated++;

        // Kontrola level upu
        this.checkLevelUp();

        // Generování ingrediencí jako odměny
        const ingredients = this.generateBossRewards();
        this.addIngredientsToInventory(ingredients);

        // Vytvoření nového bosse
        this.currentBoss = this.generateNewBoss();
        this.updateBossUI();
        this.updateUI();
    }

    generateBossRewards() {
        const numIngredients = 1 + Math.floor(Math.random() * 3); // 1-3 ingredience
        const rewards = [];
        
        for (let i = 0; i < numIngredients; i++) {
            rewards.push(this.generateRandomIngredient(this.currentBoss.rarity));
        }
        
        return rewards;
    }

    addIngredientsToInventory(ingredients) {
        const inventory = document.getElementById('ingredients-inventory');
        
        ingredients.forEach(ingredient => {
            const element = document.createElement('div');
            element.className = `ingredient draggable ${ingredient.rarity.toLowerCase()}`;
            element.draggable = true;
            element.id = `ingredient-${Date.now()}-${Math.random()}`;
            element.innerHTML = `
                <h4>${ingredient.name}</h4>
                <p>Efekt: ${GAME_CONFIG.POTIONS.TYPES[ingredient.effect]}</p>
                <p>Hodnota: ${ingredient.value}</p>
            `;
            inventory.appendChild(element);
            this.currentIngredients.push({...ingredient, id: element.id});
        });
    }

    checkLevelUp() {
        const expNeeded = this.player.gameStats.level * 100;
        if (this.player.gameStats.experience >= expNeeded) {
            this.player.gameStats.level++;
            this.player.gameStats.experience -= expNeeded;
            this.player.gameStats.clickPower++;
            alert(`Gratulujeme! Dosáhli jste úrovně ${this.player.gameStats.level}!`);
        }
    }

    updateBossUI() {
        const boss = this.currentBoss;
        document.getElementById('boss-level').textContent = boss.level;
        document.getElementById('boss-rarity').textContent = boss.rarity;
        document.getElementById('boss-name').textContent = boss.name;
        document.getElementById('boss-health').textContent = 
            `${Math.ceil(boss.health)}/${boss.maxHealth}`;
        this.updateBossHealthBar();
    }

    setupPotionUsage() {
        const potionsInventory = document.getElementById('potions-inventory');
        potionsInventory.addEventListener('click', (e) => {
            const potionElement = e.target.closest('.potion');
            if (potionElement) {
                this.usePotion(potionElement.id);
            }
        });
    }

    usePotion(potionId) {
        const potionIndex = this.potions.findIndex(p => p.id === potionId);
        if (potionIndex === -1) return;

        const potion = this.potions[potionIndex];
        let buffMessage = '';
        
        // Aplikace efektu lektvaru
        switch (potion.effect) {
            case 'STRENGTH':
                this.player.gameStats.clickPower += potion.power;
                buffMessage = `🗡️ Síla kliknutí zvýšena o ${potion.power}!`;
                break;
            case 'HEALTH':
                this.player.buffs.health += potion.power;
                buffMessage = `❤️ Zdraví obnoveno o ${potion.power}!`;
                break;
            case 'LUCK':
                this.player.buffs.luck += potion.power;
                buffMessage = `🍀 Štěstí zvýšeno o ${potion.power}!`;
                break;
            case 'EXPERIENCE':
                this.player.gameStats.experience += potion.power;
                buffMessage = `📚 Získáno ${potion.power} XP!`;
                this.checkLevelUp();
                break;
        }

        // Odstranění použitého lektvaru
        this.potions.splice(potionIndex, 1);
        const element = document.getElementById(potionId);
        if (element) {
            element.classList.add('potion-used');
            setTimeout(() => element.remove(), 500);
        }

        // Zobrazení efektu a aktualizace UI
        this.showBuffEffect(buffMessage);
        this.updateUI();
        console.log('Aktuální statistiky:', this.player);
    }

    showBuffEffect(message) {
        const effectElement = document.createElement('div');
        effectElement.className = 'buff-effect';
        effectElement.textContent = message;
        document.body.appendChild(effectElement);
        
        setTimeout(() => effectElement.remove(), 2000);
    }

    addPotionToInventory(potion) {
        const inventory = document.getElementById('potions-inventory');
        const element = document.createElement('div');
        const rarity = this.calculatePotionRarity(potion.power);
        element.className = `potion ${potion.effect.toLowerCase()} ${rarity}`;
        element.id = potion.id;
        element.innerHTML = `
            <h4>${potion.name}</h4>
            <p>Síla: +${potion.power}</p>
            <p>Vzácnost: ${rarity}</p>
            <p class="use-hint">Klikni pro použití</p>
        `;
        inventory.appendChild(element);
        this.potions.push(potion);
    }

    calculatePotionRarity(power) {
        if (power >= 50) return 'LEGENDARY';
        if (power >= 30) return 'EPIC';
        if (power >= 20) return 'RARE';
        if (power >= 10) return 'UNCOMMON';
        return 'COMMON';
    }

    async saveGameState() {
        try {
            const token = localStorage.getItem('token');
            if (!token) return;

            // Připravíme data pro uložení
            const gameData = {
                gameStats: this.player.gameStats,
                buffs: this.player.buffs,
                inventory: {
                    ingredients: this.currentIngredients.map(ing => ({
                        id: ing.id,
                        name: ing.name,
                        rarity: ing.rarity,
                        effect: ing.effect,
                        value: ing.value
                    })),
                    potions: this.potions.map(pot => ({
                        id: pot.id,
                        name: pot.name,
                        effect: pot.effect,
                        power: pot.power,
                        value: pot.value
                    }))
                }
            };

            const response = await fetch('/api/user/update-stats', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(gameData)
            });

            if (!response.ok) {
                console.error('Chyba při ukládání stavu hry');
            } else {
                console.log('Stav hry úspěšně uložen');
            }
        } catch (error) {
            console.error('Chyba při komunikaci se serverem:', error);
        }
    }

    async loadGameState() {
        try {
            const token = localStorage.getItem('token');
            if (!token) return;

            const response = await fetch('/api/user/data', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.ok) {
                const userData = await response.json();
                
                // Načtení základních statistik
                this.player.gameStats = userData.gameStats;
                this.player.buffs = userData.buffs;
                
                // Načtení ingrediencí
                this.currentIngredients = [];
                const ingredientsInventory = document.getElementById('ingredients-inventory');
                ingredientsInventory.innerHTML = ''; // Vyčistíme současný inventář
                
                if (userData.inventory && userData.inventory.ingredients) {
                    userData.inventory.ingredients.forEach(ingredient => {
                        this.addIngredientsToInventory([ingredient]);
                    });
                }
                
                // Načtení lektvarů
                this.potions = [];
                const potionsInventory = document.getElementById('potions-inventory');
                potionsInventory.innerHTML = ''; // Vyčistíme současný inventář
                
                if (userData.inventory && userData.inventory.potions) {
                    userData.inventory.potions.forEach(potion => {
                        this.addPotionToInventory(potion);
                    });
                }
                
                this.updateUI();
            }
        } catch (error) {
            console.error('Chyba při načítání stavu hry:', error);
        }
    }

    updateGameState() {
        this.updateUI();
        this.saveGameState();
    }
}

// Globální instance hry
let gameInstance = null;

// Funkce pro inicializaci hry
function initGame() {
    gameInstance = new Game();
}

socket.on('connect', () => {
    console.log('Připojeno k serveru');
});

// Přidáme globální error handling
window.onerror = function(msg, url, lineNo, columnNo, error) {
    console.error('Global error:', {
        message: msg,
        url: url,
        line: lineNo,
        column: columnNo,
        error: error,
        stack: error?.stack
    });
    return false;
}; 