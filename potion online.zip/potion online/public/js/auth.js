function showRegister() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
}

function showLogin() {
    document.getElementById('login-form').style.display = 'block';
    document.getElementById('register-form').style.display = 'none';
}

async function register() {
    const username = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;

    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        });

        const data = await response.json();
        if (response.ok) {
            alert('Registrace úspěšná! Nyní se můžete přihlásit.');
            showLogin();
        } else {
            alert(data.message || 'Chyba při registraci');
        }
    } catch (error) {
        alert('Chyba při komunikaci se serverem');
    }
}

async function login() {
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    if (!username || !password) {
        alert('Vyplňte prosím všechna pole');
        return;
    }

    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        });

        const data = await response.json();
        if (response.ok) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('username', data.username);
            showGame();
        } else {
            alert(data.message || 'Nesprávné přihlašovací údaje');
        }
    } catch (error) {
        console.error('Chyba:', error);
        alert('Chyba při komunikaci se serverem');
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    document.getElementById('auth-container').style.display = 'block';
    document.getElementById('game-container').style.display = 'none';
}

function showGame() {
    document.getElementById('auth-container').style.display = 'none';
    document.getElementById('game-container').style.display = 'block';
    document.getElementById('username-display').textContent = 
        localStorage.getItem('username');
    initGame();
}

// Kontrola při načtení stránky
window.onload = () => {
    const token = localStorage.getItem('token');
    if (token) {
        showGame();
    }
}; 